
import React, { useEffect, useState } from "react";

export default function App() {
  const [seats, setSeats] = useState([]);

  useEffect(() => {
    fetch("https://your-backend.vercel.app/api/seats")
      .then(res => res.json())
      .then(data => setSeats(data));
  }, []);

  const bookSeat = async (seatNumber) => {
    const name = prompt("Enter your name");
    await fetch("https://your-backend.vercel.app/api/seats", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seatNumber, name })
    });

    alert("Seat Booked!");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Farewell Dining Hall</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10 }}>
        {seats.map((s, i) => (
          <div
            key={i}
            onClick={() => bookSeat(s.seatNumber)}
            style={{
              padding: 20,
              background: s.isBooked ? "red" : "green",
              color: "white",
              cursor: "pointer"
            }}
          >
            {s.seatNumber} {s.name ? `- ${s.name}` : ""}
          </div>
        ))}
      </div>
    </div>
  );
}
