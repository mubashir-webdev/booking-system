
import mongoose from "mongoose";

const SeatSchema = new mongoose.Schema({
  seatNumber: String,
  side: String,
  isBooked: { type: Boolean, default: false },
  bookedBy: String,
  name: String,
});

export default mongoose.models.Seat || mongoose.model("Seat", SeatSchema);
