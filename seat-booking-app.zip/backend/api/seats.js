
import { connectDB } from "../db.js";
import Seat from "../models/Seat.js";

export default async function handler(req, res) {
  await connectDB();

  if (req.method === "GET") {
    const seats = await Seat.find();
    res.json(seats);
  }

  if (req.method === "POST") {
    const { seatNumber, name } = req.body;

    const seat = await Seat.findOne({ seatNumber });
    if (!seat || seat.isBooked) {
      return res.status(400).json({ error: "Seat not available" });
    }

    seat.isBooked = true;
    seat.name = name;

    await seat.save();

    res.json({ success: true, seat });
  }
}
